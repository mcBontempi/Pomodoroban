//
//  NSURLSession+NSURLSession___swiz.h
//  Pomodoroban
//
//  Created by mcBontempi on 05/07/2017.
//  Copyright © 2017 LondonSwift. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSURLSession (NSURLSession___swiz)

@end
