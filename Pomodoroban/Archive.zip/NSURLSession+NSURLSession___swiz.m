//
//  NSURLSession+NSURLSession___swiz.m
//  Pomodoroban
//
//  Created by mcBontempi on 05/07/2017.
//  Copyright © 2017 LondonSwift. All rights reserved.
//

#import "NSURLSession+NSURLSession___swiz.h"
#import <objc/message.h>
@implementation NSURLSession (NSURLSession___swiz)

+ (void)load {
    
    static dispatch_once_t once_token;
    dispatch_once(&once_token,  ^{
        
        SEL viewWillAppearSelector = @selector(dataTaskWithRequest:completionHandler:);
        SEL viewWillAppearLoggerSelector = @selector(loggedDataTaskWithRequest:completionHandler:);
        Method originalMethod = class_getInstanceMethod(self, viewWillAppearSelector);
        Method extendedMethod = class_getInstanceMethod(self, viewWillAppearLoggerSelector);
        method_exchangeImplementations(originalMethod, extendedMethod);
        
         viewWillAppearSelector = @selector(dataTaskWithRequest:);
         viewWillAppearLoggerSelector = @selector(loggedDataTaskWithRequestNoCompletion:);
         originalMethod = class_getInstanceMethod(self, viewWillAppearSelector);
        extendedMethod = class_getInstanceMethod(self, viewWillAppearLoggerSelector);
        method_exchangeImplementations(originalMethod, extendedMethod);
    });
}

- (NSURLSessionDataTask *)loggedDataTaskWithRequestNoCompletion:(NSURLRequest *)request
{
    NSURLSessionDataTask *task = [self loggedDataTaskWithRequestNoCompletion:request];
    NSLog(@"%@",task);
    return task;
}

- (NSURLSessionDataTask *)loggedDataTaskWithRequest:(NSURLRequest *)request completionHandler:(void (^)(NSData *data, NSURLResponse *response, NSError *error))completionHandler
{
    return  [self loggedDataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        completionHandler(data,response,error);
        //line above crashes.
    }];
    
    /*
    // this works
     return  [self loggedDataTaskWithRequest:request completionHandler:completionHandler];
     */
}

@end
